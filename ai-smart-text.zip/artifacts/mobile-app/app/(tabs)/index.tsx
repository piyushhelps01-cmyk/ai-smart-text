import React, { useState } from 'react';
import {
  StyleSheet, Text, View, TouchableOpacity, ScrollView,
  SafeAreaView, StatusBar, TextInput, ActivityIndicator,
  Alert, Platform,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';

// ─────────────────────────────────────────────────────────────────────────────
// ADMOB CONFIGURATION
// ─────────────────────────────────────────────────────────────────────────────
// These are Google's official TEST IDs — safe for development and Expo Go UI
// testing. Replace every value below with your real IDs from the AdMob
// dashboard (https://admob.google.com) before publishing to the App Store.
//
// Your AdMob App IDs are also set in app.json under:
//   ios.googleMobileAdsAppId  →  replace ca-app-pub-3940256099942544~1458002511
//   android.googleMobileAdsAppId  →  replace ca-app-pub-3940256099942544~3347511713
//
// After installing react-native-google-mobile-ads in a production build, swap
// the placeholder components below for the real BannerAd / InterstitialAd
// from that package.
// ─────────────────────────────────────────────────────────────────────────────
const ADMOB_IDS = {
  // Banner ad unit IDs
  banner: Platform.OS === 'ios'
    ? 'ca-app-pub-3940256099942544/2934735716'   // ← replace with your iOS banner ID
    : 'ca-app-pub-3940256099942544/6300978111',  // ← replace with your Android banner ID

  // Interstitial ad unit IDs
  interstitial: Platform.OS === 'ios'
    ? 'ca-app-pub-3940256099942544/4411468910'   // ← replace with your iOS interstitial ID
    : 'ca-app-pub-3940256099942544/1033173712',  // ← replace with your Android interstitial ID
};

// ─────────────────────────────────────────────────────────────────────────────
// HOW TO ACTIVATE LIVE ADS AFTER PUBLISHING
// ─────────────────────────────────────────────────────────────────────────────
// 1. Publish the app via Replit Expo Launch (iOS) to get a real native build.
// 2. Add the package:  pnpm --filter @workspace/mobile-app add react-native-google-mobile-ads
// 3. Replace the SimulatedBannerAd component below with:
//      import { BannerAd, BannerAdSize } from 'react-native-google-mobile-ads';
//      <BannerAd unitId={ADMOB_IDS.banner} size={BannerAdSize.BANNER} />
// 4. Replace the simulated interstitial in handleGeneratePress with:
//      const interstitial = InterstitialAd.createForAdRequest(ADMOB_IDS.interstitial, { requestNonPersonalizedAdsOnly: true });
//      interstitial.addAdEventListener(AdEventType.LOADED, () => interstitial.show());
//      interstitial.load();
// ─────────────────────────────────────────────────────────────────────────────

// Simulated banner — replaced with <BannerAd> in a production native build
function SimulatedBannerAd() {
  return (
    <View style={styles.bannerAdPlaceholder}>
      <Text style={styles.adText}>[ AdMob Banner — Unit ID: {ADMOB_IDS.banner.slice(-10)} ]</Text>
    </View>
  );
}

export default function TabOneScreen() {
  const [activeTab, setActiveTab] = useState('Caption');
  const [inputText, setInputText] = useState('');
  const [generatedResult, setGeneratedResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const tools = [
    { id: 'Caption', name: '📱 Insta Caption' },
    { id: 'Hashtag', name: '🔥 Viral Hashtags' },
    { id: 'Tag', name: '📺 YouTube Tags' },
    { id: 'Bio', name: '💎 Smart Bio' },
  ];

  const generateAIContent = (type: string, topic: string): string => {
    if (!topic) return 'Please enter a topic first!';
    const cleanTopic = topic.toLowerCase().trim();
    if (type === 'Caption') {
      return `🚀 VIRAL CAPTIONS FOR: "${topic}"\n\n1. Leveling up my game with ${topic}. No lookin' back! 🔥\n2. They talked about it, I'm making it happen. #Trending\n3. Current mood: Obsessed with ${topic} 💎\n4. Drop a ❤️ if you agree with this vibe!`;
    }
    if (type === 'Hashtag') {
      return `🔥 TRENDING HASHTAGS FOR: "${topic}"\n\n#${cleanTopic.replace(/\s+/g, '')} #viral #trending #explore #foryou #foryoupage #instagramnews #aitools #success #mindset2026`;
    }
    if (type === 'Tag') {
      return `📺 HIGH-SEO YOUTUBE TAGS FOR: "${topic}"\n\n${topic}, how to viral ${topic}, best ${topic} video, trending shorts, ${topic} tutorial 2026, tech hacks`;
    }
    if (type === 'Bio') {
      return `💎 PREMIUM BIO FOR: "${topic}"\n\n👑 Believer | Creator | Tech Enthusiast\n🎯 Hustling with ${topic}\n👇 Check out my latest project below!\n⚡ Living life in 3D perspective.`;
    }
    return 'Invalid Selection';
  };

  const handleCopy = async () => {
    if (!generatedResult) return;
    await Clipboard.setStringAsync(generatedResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Simulates an interstitial ad flow.
  // In production: replace setTimeout block with InterstitialAd from react-native-google-mobile-ads
  // using unit ID: ADMOB_IDS.interstitial
  const handleGeneratePress = () => {
    if (!inputText.trim()) {
      Alert.alert('Error', 'Please type a topic or keyword first!');
      return;
    }
    setLoading(true);
    setGeneratedResult('');
    setTimeout(() => {
      setLoading(false);
      const result = generateAIContent(activeTab, inputText);
      setGeneratedResult(result);
      Alert.alert(
        'Ad Complete ✅',
        'Interstitial Ad closed. Revenue credited to AdMob!\n\nAd Unit: ' + ADMOB_IDS.interstitial.slice(-10),
      );
    }, 2500);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <Text style={styles.logoText}>AI SMART TEXT</Text>
        <Text style={styles.founderText}>Piyush Yadav - Founder & CEO</Text>
      </View>

      <View style={styles.navigationGrid}>
        {tools.map((tool) => (
          <TouchableOpacity
            key={tool.id}
            style={[styles.card, activeTab === tool.id && styles.activeCard]}
            onPress={() => {
              setActiveTab(tool.id);
              setGeneratedResult('');
            }}
          >
            <Text style={[styles.cardText, activeTab === tool.id && styles.activeCardText]}>
              {tool.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.inputSection}>
        <Text style={styles.inputLabel}>Enter Topic / Keyword:</Text>
        <TextInput
          style={styles.textInput}
          placeholder="e.g., Coding, My New Car, Gym Reels..."
          placeholderTextColor="#4B5563"
          value={inputText}
          onChangeText={setInputText}
        />
        <TouchableOpacity style={styles.generateButton} onPress={handleGeneratePress}>
          <Text style={styles.buttonText}>🚀 Generate & Watch Ad</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.workspace}>
        <Text style={styles.sectionTitle}>Generated {activeTab}:</Text>
        <View style={styles.previewBox}>
          {loading ? (
            <View style={styles.loaderContainer}>
              <ActivityIndicator size="large" color="#00F0FF" />
              <Text style={styles.loadingText}>Loading Video Advertisement...</Text>
            </View>
          ) : (
            <Text style={styles.outputText}>
              {generatedResult || `Your viral AI ${activeTab} will appear here instantly after clicking generate.`}
            </Text>
          )}
        </View>

        {generatedResult ? (
          <TouchableOpacity
            style={[styles.copyButton, copied && styles.copyButtonSuccess]}
            onPress={handleCopy}
            activeOpacity={0.75}
          >
            <Text style={styles.copyButtonText}>
              {copied ? '✅ Copied!' : '📋 Copy to Clipboard'}
            </Text>
          </TouchableOpacity>
        ) : null}
      </ScrollView>

      {/* Banner Ad — swap with <BannerAd> in production native build */}
      <SimulatedBannerAd />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A0E1A' },
  header: { padding: 15, borderBottomWidth: 1, borderBottomColor: '#1E293B', alignItems: 'center' },
  logoText: { fontSize: 22, fontWeight: 'bold', color: '#00F0FF', letterSpacing: 2 },
  founderText: { fontSize: 11, color: '#94A3B8', marginTop: 2, fontStyle: 'italic' },
  navigationGrid: { flexDirection: 'row', flexWrap: 'wrap', padding: 10, justifyContent: 'space-between' },
  card: { width: '46%', backgroundColor: '#161F38', padding: 14, borderRadius: 12, marginVertical: 6, marginHorizontal: '2%', alignItems: 'center', borderWidth: 1, borderColor: '#22325A' },
  activeCard: { backgroundColor: '#1E1B4B', borderColor: '#8B5CF6' },
  cardText: { color: '#94A3B8', fontSize: 13, fontWeight: '600' },
  activeCardText: { color: '#00F0FF' },
  inputSection: { padding: 20, backgroundColor: '#111827', marginHorizontal: 15, borderRadius: 14, borderWidth: 1, borderColor: '#1F2937' },
  inputLabel: { color: '#94A3B8', fontSize: 14, marginBottom: 8, fontWeight: '500' },
  textInput: { backgroundColor: '#0A0E1A', color: '#FFFFFF', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#374151', fontSize: 15, marginBottom: 12 },
  generateButton: { backgroundColor: '#8B5CF6', padding: 14, borderRadius: 10, alignItems: 'center' },
  buttonText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 15 },
  workspace: { flex: 1, paddingHorizontal: 20, paddingTop: 15 },
  sectionTitle: { fontSize: 16, color: '#FFFFFF', fontWeight: 'bold', marginBottom: 10 },
  previewBox: { backgroundColor: '#161F38', borderRadius: 12, padding: 15, minHeight: 130, borderWidth: 1, borderColor: '#22325A', marginBottom: 20 },
  outputText: { color: '#E2E8F0', fontSize: 14, lineHeight: 22 },
  loaderContainer: { alignItems: 'center', justifyContent: 'center', paddingVertical: 20 },
  loadingText: { color: '#00F0FF', marginTop: 10, fontSize: 13 },
  copyButton: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: '#00F0FF', borderRadius: 10,
    paddingVertical: 12, marginBottom: 24,
    backgroundColor: 'rgba(0,240,255,0.07)',
  },
  copyButtonSuccess: {
    borderColor: '#00FF88',
    backgroundColor: 'rgba(0,255,136,0.07)',
  },
  copyButtonText: { color: '#00F0FF', fontWeight: 'bold', fontSize: 14, letterSpacing: 0.5 },
  bannerAdPlaceholder: { height: 55, backgroundColor: '#1E293B', justifyContent: 'center', alignItems: 'center', borderTopWidth: 1, borderTopColor: '#00F0FF22' },
  adText: { color: '#00F0FF', fontSize: 11, fontWeight: 'bold' },
});
